package com.example.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.drawable.ColorDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import com.example.myapplication.R;
import com.example.myapplication.dataBase.DatabaseHelper;
import com.example.myapplication.models.Colors;
import com.example.myapplication.models.Product;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ProductDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView productImage, EditDPImage;
    EditText edproductName, edproductDescription, edproductRegularPrice, edproductSalePrice;
    Button btUpdate, btDelet;
    Spinner spinnerColor, spinnerStores;
    private Uri uriFilePath;
    private static final int CAMERA_REQUEST1 = 1880;
    static final int result2 = 3;
    Uri img;
    Bitmap bm;
    String imageName = "";
    private File photo;
    String productId,productName,productDiscription,productRegularPrice,productSalePrice,productColor,productStores;
    DatabaseHelper databaseHelper;
    private String imagephoto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_details);


        productImage = findViewById(R.id.productImage);
        EditDPImage = findViewById(R.id.EditDPImage);
        edproductName = findViewById(R.id.productName);
        edproductDescription = findViewById(R.id.productDescription);
        edproductRegularPrice = findViewById(R.id.productRegularPrice);
        edproductSalePrice = findViewById(R.id.productSalePrice);
        spinnerColor = findViewById(R.id.spinnerColor);
        spinnerStores = findViewById(R.id.spinnerStores);
        btUpdate = findViewById(R.id.btUpdate);
        btDelet = findViewById(R.id.btDelet);

        EditDPImage.setOnClickListener(this);
        btUpdate.setOnClickListener(this);
        btDelet.setOnClickListener(this);
        productImage.setOnClickListener(this);
        databaseHelper=new DatabaseHelper(this);
        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            builder.detectFileUriExposure();
        }

        productId=getIntent().getStringExtra("productId");
        productName=getIntent().getStringExtra("productName");
        productDiscription=getIntent().getStringExtra("productDiscription");
        productRegularPrice=getIntent().getStringExtra("productRegularPrice");
        productSalePrice=getIntent().getStringExtra("productSalePrice");
        productColor=getIntent().getStringExtra("productColor");
        productStores=getIntent().getStringExtra("productStores");
        imagephoto=getIntent().getStringExtra("imagephoto");


        edproductName.setText(productName);
        edproductDescription.setText(productDiscription);
        edproductRegularPrice.setText(productRegularPrice);
        edproductSalePrice.setText(productSalePrice);
        productImage.setImageBitmap(getImage(imagephoto));





        List<String> colorList = new ArrayList<>();

        colorList.add("Red");
        colorList.add("Green");
        colorList.add("Yellow");
        colorList.add("Black");
        colorList.add("pink");


        spinnerAdapter dAdapter = new spinnerAdapter(ProductDetailsActivity.this, R.layout.custom_spinner, colorList);
        dAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dAdapter.addAll(colorList);
        dAdapter.add("Select Color");
        spinnerColor.setAdapter(dAdapter);
        spinnerColor.setSelection(dAdapter.getCount());

        List<String> storeList = new ArrayList<>();
        storeList.add("Peter England");
        storeList.add("Max Bupa");
        storeList.add("Civic Notebook");
        spinnerAdapter dAdapter1 = new spinnerAdapter(ProductDetailsActivity.this, R.layout.custom_spinner, storeList);
        dAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dAdapter1.addAll(storeList);
        dAdapter1.add("Select Stores");
        spinnerStores.setAdapter(dAdapter1);
        spinnerStores.setSelection(dAdapter1.getCount());

        for(int i=0;i<colorList.size();i++)
        {
            if(productColor.equals(colorList.get(i))){
                Toast.makeText(this, ""+productColor, Toast.LENGTH_SHORT).show();
                spinnerColor.setSelection(i);

            }

        }

        for(int i=0;i<storeList.size();i++)
        {
            if(productStores.equals(storeList.get(i))){
                Toast.makeText(this, ""+productColor, Toast.LENGTH_SHORT).show();
                spinnerStores.setSelection(i);

            }

        }

        spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                productColor = spinnerColor.getSelectedItem().toString();




            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        spinnerStores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                productStores = spinnerStores.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.EditDPImage:

                final Dialog dialog = new Dialog(ProductDetailsActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.upload_image);
                final TextView gallary = dialog.findViewById(R.id.gallary);
                TextView camera = dialog.findViewById(R.id.camera);

                dialog.show();

                camera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        camera();
                        dialog.dismiss();
                    }
                });

                gallary.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        gallery();
                        dialog.dismiss();
                    }
                });
                break;

            case R.id.btUpdate:
                String productName=edproductName.getText().toString();
                String productDescription=edproductDescription.getText().toString();
                String productRegularPrice=edproductRegularPrice.getText().toString();
                String productSalePrice=edproductSalePrice.getText().toString();
                productColor=spinnerColor.getSelectedItem().toString();
                productStores=spinnerStores.getSelectedItem().toString();


                if(productName.equals("")){
                    edproductName.setError(getString(R.string.enter_product_name));
                    edproductName.requestFocus();

                }
                else if(productDescription.equals("")){
                    edproductDescription.setError(getString(R.string.enter_product_description));
                    edproductDescription.requestFocus();

                }
                else if(productRegularPrice.equals("")){
                    edproductRegularPrice.setError(getString(R.string.enter_product_regularprice));
                    edproductRegularPrice.requestFocus();
                }
                else if(productSalePrice.equals("")){
                    edproductSalePrice.setError(getString(R.string.enter_product_salesprice));
                    edproductSalePrice.requestFocus();
                }
                else if(productColor.equals("Select Color")){
                    Toast.makeText(ProductDetailsActivity.this, "please select color", Toast.LENGTH_SHORT).show();
                }
                else if(productStores.equals("Select Stores")){
                    Toast.makeText(ProductDetailsActivity.this, "please select stores", Toast.LENGTH_SHORT).show();
                }

                else {
                    databaseHelper.updateCompanyData(productId,productName,productDescription,productRegularPrice,productSalePrice,imagephoto,productColor,productStores);
                    databaseHelper.close();


                }


                break;

            case R.id.btDelet:

                DatabaseHelper databaseHelper = new DatabaseHelper(ProductDetailsActivity.this);
                databaseHelper.deleteData(productId);
                databaseHelper.close();
                startActivity(new Intent(ProductDetailsActivity.this,ShowProductActivity.class));


                break;
            case R.id.productImage:
                final Dialog pictureDialog = new Dialog(ProductDetailsActivity.this);
                pictureDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                pictureDialog.setContentView(R.layout.fullimage_show_layout);
                pictureDialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                pictureDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                ImageView profilePicFullScreen = (ImageView) pictureDialog.findViewById(R.id.profilePicFullScreen);
                pictureDialog.setCancelable(true);
                profilePicFullScreen.setImageBitmap(getImage(imagephoto));

                pictureDialog.show();

                break;
        }

    }

    public class spinnerAdapter extends ArrayAdapter<String> {

        public spinnerAdapter(Context context, int textViewResourceId, List<String> smonking) {
            super(context, textViewResourceId);
            // TODO Auto-generated constructor stub
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            int count = super.getCount();
            return count > 0 ? count - 1 : count;
        }
    }
    private void gallery() {
        boolean readExternal = com.example.myapplication.helperClass.Permission.checkPermissionReadExternal(ProductDetailsActivity.this);
        boolean camera = com.example.myapplication.helperClass.Permission.checkPermissionCamera(ProductDetailsActivity.this);
        if (readExternal || camera) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, result2);
        }
    }

    @SuppressLint("UnsupportedChromeOsCameraSystemFeature")
    private void camera() {

        PackageManager packageManager = ProductDetailsActivity.this.getPackageManager();

        boolean readExternal = com.example.myapplication.helperClass.Permission.checkPermissionReadExternal(ProductDetailsActivity.this);
        boolean camera = com.example.myapplication.helperClass.Permission.checkPermissionCamera(ProductDetailsActivity.this);
        if (readExternal || camera) {
            if (packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
                File mainDirectory = new File(Environment.getExternalStorageDirectory(), "MyFolder/tmp");
                if (!mainDirectory.exists())
                    mainDirectory.mkdirs();
                Calendar calendar = Calendar.getInstance();
                uriFilePath = Uri.fromFile(new File(mainDirectory, "IMG" + calendar.getTimeInMillis() + ".jpg"));
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFilePath);
                startActivityForResult(intent, CAMERA_REQUEST1);
            }
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == result2) {
                img = data.getData();

                String sel_path = getpath(img);

                try {

                    if (sel_path == null) {
                        Toast.makeText(this, "Bad image it can not be selected", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("selectedImagePath", sel_path);
                        String[] bits = sel_path.split("/");
                        imageName = bits[bits.length - 1];

                        Log.d("imageName", imageName);
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inJustDecodeBounds = true;
                        BitmapFactory.decodeFile(sel_path, options);
                        final int REQUIRED_SIZE = 500;
                        int scale = 1;
                        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
                            scale *= 2;
                        options.inSampleSize = scale;
                        options.inJustDecodeBounds = false;
                        bm = BitmapFactory.decodeFile(sel_path, options);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bm.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        imagephoto = sel_path;
//
                        productImage.setImageBitmap(bm);

                    }
                } catch (Exception e) {

                    Toast.makeText(this, "bad image", Toast.LENGTH_SHORT).show();
                }


            } else if (requestCode == CAMERA_REQUEST1) {

                try {
                    Bitmap bm = BitmapFactory.decodeFile(uriFilePath.getPath());//
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    imagephoto=uriFilePath.getPath();
                    productImage.setImageBitmap(bm);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private String getpath(Uri img) {
        String[] p = {MediaStore.Images.Media.DATA};
        Cursor cursor = ProductDetailsActivity.this.getContentResolver().query(img, p, null, null, null);
        int col = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String file_path = cursor.getString(col);

        try {
            photo = new File(new URI("file://" + file_path.replace(" ", "%20")));

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return cursor.getString(col);
    }
    public static Bitmap getImage(String image) {
        return BitmapFactory.decodeFile(image );
    }
}
