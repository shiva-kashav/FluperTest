package com.example.myapplication.dataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "fluper.db";
    public static final String COMPANY_TABLE = "company_name";
    public static final String COL_0 = "productId";
    public static final String COL_1 = "productName";
    public static final String COL_2 = "productDescription";
    public static final String COL_3 = "productRegularPrice";
    public static final String COL_4 = "productSalePrice";
    public static final String COL_5 = "productPhoto";
    public static final String COL_6 = "productColors";
    public static final String COL_7 = "productStoreDictionary";

Context mcontexxt;

    public DatabaseHelper(Context context)

    {
        super(context, DATABASE_NAME, null, 1);
        mcontexxt=context;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {


        sqLiteDatabase.execSQL("create table " + COMPANY_TABLE +" (productId INTEGER PRIMARY KEY AUTOINCREMENT,productName TEXT,productDescription TEXT,productRegularPrice TEXT,productSalePrice TEXT,productPhoto BLOB ,productColors TEXT,productStoreDictionary TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+COMPANY_TABLE);
        //  db.execSQL("DROP TABLE IF EXISTS " + TABLE_EMPLOYEE);
        onCreate(sqLiteDatabase);
    }

public boolean insertData(String productName,String productDiscription,String productRegularPrice,String productSaleprice,String  productPhoto,String productColor,String productStores){

    SQLiteDatabase db = this.getWritableDatabase();

    ContentValues contentValues = new ContentValues();
    contentValues.put(COL_1,productName);
    contentValues.put(COL_2,productDiscription);
    contentValues.put(COL_3,productRegularPrice);
    contentValues.put(COL_4,productSaleprice);
    contentValues.put(COL_5,productPhoto);
    contentValues.put(COL_6,productColor);
    contentValues.put(COL_7,productStores);


    long result = db.insert(COMPANY_TABLE,null ,contentValues);
    if(result == -1) {
        Toast.makeText(mcontexxt, "faild ! ", Toast.LENGTH_SHORT).show();
        return false;
    }
    else {
        Toast.makeText(mcontexxt, "Success !", Toast.LENGTH_SHORT).show();
        return true;
    }
}
    public boolean updateCompanyData(String productId,String productName,String productDiscription,String productRegularPrice,String productSaleprice,String productPhoto,String productColor,String productStores)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_0,productId);
        contentValues.put(COL_1,productName);
        contentValues.put(COL_2,productDiscription);
        contentValues.put(COL_3,productRegularPrice);
        contentValues.put(COL_4,productSaleprice);
        contentValues.put(COL_5,productPhoto);
        contentValues.put(COL_6,productColor);
        contentValues.put(COL_7,productStores);

        db.update(COMPANY_TABLE, contentValues, "productId = ?",new String[] { productId });
        Toast.makeText(mcontexxt, "Success !", Toast.LENGTH_SHORT).show();
        return true;
    }
    public boolean deleteData (String productId)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(COMPANY_TABLE, "productId = ?",new String[] {productId});
        if(result == -1) {
            Toast.makeText(mcontexxt, "faild Delete! ", Toast.LENGTH_SHORT).show();
            return false;
        }
        else {
            Toast.makeText(mcontexxt, "Success Delete!", Toast.LENGTH_SHORT).show();
            return true;
        }
    }
    public Cursor getAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + COMPANY_TABLE, null);
        return res;
    }
}
