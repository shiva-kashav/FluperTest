package com.example.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.dataBase.DatabaseHelper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class CreateProductActivity extends AppCompatActivity implements View.OnClickListener {

    ImageView productImage, EditDPImage;
    EditText productName, productDescription, productRegularPrice, productSalePrice;
    Button btAddProduct;
    Spinner spinnerColor, spinnerStores;
    private Uri uriFilePath;
    private static final int CAMERA_REQUEST1 = 1880;
    static final int result2 = 3;
    Uri img;

    String imageName = "";
    private File photo;

    String colorId, storeId;
    DatabaseHelper databaseHelper;
    String byteArray = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_product);

        productImage = findViewById(R.id.productImage);
        EditDPImage = findViewById(R.id.EditDPImage);
        productName = findViewById(R.id.productName);
        productDescription = findViewById(R.id.productDescription);
        productRegularPrice = findViewById(R.id.productRegularPrice);
        productSalePrice = findViewById(R.id.productSalePrice);
        spinnerColor = findViewById(R.id.spinnerColor);
        spinnerStores = findViewById(R.id.spinnerStores);
        btAddProduct = findViewById(R.id.btAddProduct);

        EditDPImage.setOnClickListener(this);
        btAddProduct.setOnClickListener(this);
        databaseHelper = new DatabaseHelper(this);
        btAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String product_name = productName.getText().toString();
                String pro_discription = productDescription.getText().toString();
                String pr_regular_price = productRegularPrice.getText().toString();
                String pro_image = byteArray;
                String pro_sale = productSalePrice.getText().toString();
                String pro_color = spinnerColor.getSelectedItem().toString();
                String pro_spinnerStores = spinnerStores.getSelectedItem().toString();


                if (product_name.equals("")) {
                    productName.setError(getString(R.string.enter_product_name));
                    productName.requestFocus();

                } else if (pro_discription.equals("")) {
                    productDescription.setError(getString(R.string.enter_product_description));
                    productDescription.requestFocus();

                } else if (pr_regular_price.equals("")) {
                    productRegularPrice.setError(getString(R.string.enter_product_regularprice));
                    productRegularPrice.requestFocus();
                } else if (pro_sale.equals("")) {
                    productSalePrice.setError(getString(R.string.enter_product_salesprice));
                    productSalePrice.requestFocus();
                } else if (colorId.equals("Select Color")) {
                    Toast.makeText(CreateProductActivity.this, "please select color", Toast.LENGTH_SHORT).show();
                } else if (storeId.equals("Select Stores")) {
                    Toast.makeText(CreateProductActivity.this, "please select stores", Toast.LENGTH_SHORT).show();
                } else if (pro_image == null) {
                    Toast.makeText(CreateProductActivity.this, "please insert picture", Toast.LENGTH_SHORT).show();
                } else {
                    boolean check =
                            databaseHelper.insertData(product_name, pro_discription, pr_regular_price, pro_sale, byteArray, pro_color, pro_spinnerStores);
                    databaseHelper.close();
                    if (check) {

                        productName.getText().clear();
                        productDescription.getText().clear();
                        productRegularPrice.getText().clear();
                        productSalePrice.getText().clear();

                        productImage.setImageBitmap(null);
                        selectColor();
                        selectStores();


                    }
                }

            }
        });

        StrictMode.VmPolicy.Builder builder = new StrictMode.VmPolicy.Builder();
        StrictMode.setVmPolicy(builder.build());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR2) {
            builder.detectFileUriExposure();
        }
        selectColor();
        selectStores();


    }

    public class spinnerAdapter extends ArrayAdapter<String> {

        public spinnerAdapter(Context context, int textViewResourceId, List<String> smonking) {
            super(context, textViewResourceId);
            // TODO Auto-generated constructor stub
        }

        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            int count = super.getCount();
            return count > 0 ? count - 1 : count;
        }
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()) {

            case R.id.EditDPImage:

                final Dialog dialog = new Dialog(CreateProductActivity.this);
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.upload_image);
                final TextView gallary = dialog.findViewById(R.id.gallary);
                TextView camera = dialog.findViewById(R.id.camera);

                dialog.show();

                camera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        camera();
                        dialog.dismiss();
                    }
                });

                gallary.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        gallery();
                        dialog.dismiss();
                    }
                });
                break;

            case R.id.btAddProduct:


                break;
        }
    }

    private void gallery() {
        boolean readExternal = com.example.myapplication.helperClass.Permission.checkPermissionReadExternal(CreateProductActivity.this);
        boolean camera = com.example.myapplication.helperClass.Permission.checkPermissionCamera(CreateProductActivity.this);
        if (readExternal || camera) {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, result2);
        }
    }

    @SuppressLint("UnsupportedChromeOsCameraSystemFeature")
    private void camera() {

        PackageManager packageManager = CreateProductActivity.this.getPackageManager();

        boolean readExternal = com.example.myapplication.helperClass.Permission.checkPermissionReadExternal(CreateProductActivity.this);
        boolean camera = com.example.myapplication.helperClass.Permission.checkPermissionCamera(CreateProductActivity.this);
        if (readExternal || camera) {
            if (packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
                File mainDirectory = new File(Environment.getExternalStorageDirectory(), "MyFolder/tmp");
                if (!mainDirectory.exists())
                    mainDirectory.mkdirs();
                Calendar calendar = Calendar.getInstance();
                uriFilePath = Uri.fromFile(new File(mainDirectory, "IMG" + calendar.getTimeInMillis() + ".jpg"));
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, uriFilePath);
                startActivityForResult(intent, CAMERA_REQUEST1);
            }
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == result2) {
                img = data.getData();

                String sel_path = getpath(img);

                try {

                    if (sel_path == null) {
                        Toast.makeText(this, "Bad image it can not be selected", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.d("selectedImagePath", sel_path);
                        String[] bits = sel_path.split("/");
                        imageName = bits[bits.length - 1];

                        Log.d("imageName", imageName);
                        BitmapFactory.Options options = new BitmapFactory.Options();
                        options.inJustDecodeBounds = true;
                        BitmapFactory.decodeFile(sel_path, options);
                        final int REQUIRED_SIZE = 500;
                        int scale = 1;
                        while (options.outWidth / scale / 2 >= REQUIRED_SIZE
                                && options.outHeight / scale / 2 >= REQUIRED_SIZE)
                            scale *= 2;
                        options.inSampleSize = scale;
                        options.inJustDecodeBounds = false;
                        Bitmap bm = BitmapFactory.decodeFile(sel_path, options);
                        ByteArrayOutputStream stream = new ByteArrayOutputStream();
                        bm.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byteArray = sel_path;


                        productImage.setImageBitmap(bm);

                    }
                } catch (Exception e) {

                    Toast.makeText(this, "bad image", Toast.LENGTH_SHORT).show();
                }


            } else if (requestCode == CAMERA_REQUEST1) {
//
                try {

                    Bitmap bm = BitmapFactory.decodeFile(uriFilePath.getPath());

                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byteArray = uriFilePath.getPath();
                    Log.d(" camera Path*********", uriFilePath.getPath());
                    productImage.setImageBitmap(bm);


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private String getpath(Uri img) {
        String[] p = {MediaStore.Images.Media.DATA};
        Cursor cursor = CreateProductActivity.this.getContentResolver().query(img, p, null, null, null);
        int col = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
        cursor.moveToFirst();
        String file_path = cursor.getString(col);

        try {
            photo = new File(new URI("file://" + file_path.replace(" ", "%20")));

        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        return cursor.getString(col);
    }
    public void selectColor(){

        List<String> colorList = new ArrayList<>();
        colorList.add("Red");
        colorList.add("Green");
        colorList.add("Yellow");
        colorList.add("Black");
        colorList.add("Pink");

        spinnerAdapter dAdapter = new spinnerAdapter(CreateProductActivity.this, R.layout.custom_spinner, colorList);
        dAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dAdapter.addAll(colorList);
        dAdapter.add("Select Color");
        spinnerColor.setAdapter(dAdapter);
        spinnerColor.setSelection(dAdapter.getCount());

        spinnerStores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                storeId = spinnerStores.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    public void selectStores(){

        List<String> storeList = new ArrayList<>();
        storeList.add("Peter England");
        storeList.add("Max Bupa");
        storeList.add("Civic Notebook");

        spinnerAdapter dAdapter1 = new spinnerAdapter(CreateProductActivity.this, R.layout.custom_spinner, storeList);
        dAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dAdapter1.addAll(storeList);
        dAdapter1.add("Select Stores");
        spinnerStores.setAdapter(dAdapter1);
        spinnerStores.setSelection(dAdapter1.getCount());


        spinnerColor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                colorId = spinnerColor.getSelectedItem().toString();


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

    }
}