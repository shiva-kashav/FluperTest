package com.example.myapplication.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;
import com.example.myapplication.activity.ProductDetailsActivity;
import com.example.myapplication.activity.ShowProductActivity;
import com.example.myapplication.dataBase.DatabaseHelper;
import com.example.myapplication.models.Colors;
import com.example.myapplication.models.Product;

import java.util.List;

public class ShowProductAdapter extends RecyclerView.Adapter<ShowProductAdapter.MyViewHolder> {
    Context context;
    List<Product> productslist;

    public ShowProductAdapter(Context context, List<Product> productslist) {

        this.context = context;
        this.productslist = productslist;
    }

    @NonNull
    @Override
    public ShowProductAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.productshow_recyclerview_layout, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ShowProductAdapter.MyViewHolder holder, int position) {

        final Product model = productslist.get(position);

        holder.productName.setText(model.getName());
        holder.productDescription.setText(model.getDescription());
        holder.productImage.setImageBitmap(getImage(model.productPhoto));


        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String productId= String.valueOf(model.getId());
                String productName = model.getName();
                String productDiscription = model.getDescription();
                String productRegularPrice = model.getRegularPrice();
                String productSalePrice = model.getSalePrice();
                String productColor = model.getColors();
                String productStores = model.getStores();
                String productPhoto = model.productPhoto;


                    Intent extras = new Intent(context, ProductDetailsActivity.class);
                    extras.putExtra("productId",productId);
                    extras.putExtra("productName", productName);
                    extras.putExtra("productDiscription", productDiscription);
                    extras.putExtra("productRegularPrice", productRegularPrice);
                    extras.putExtra("productSalePrice", productSalePrice);
                    extras.putExtra("productColor", productColor);
                    extras.putExtra("productStores", productStores);
                    extras.putExtra("productPhotos", productPhoto);
                    extras.putExtra("imagephoto",productPhoto);
                    context.startActivity(extras);

            }
        });

    }

    @Override
    public int getItemCount() {
        return productslist.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView productName, productDescription;
        LinearLayout linearLayout;
        ImageView productImage;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            productName = itemView.findViewById(R.id.productName);
            productImage = itemView.findViewById(R.id.productImage);
            productDescription = itemView.findViewById(R.id.productDescription);
            linearLayout = itemView.findViewById(R.id.linearLayout);


        }
    }

    public static Bitmap getImage(String image) {
        return    BitmapFactory.decodeFile(image);
    }
}
