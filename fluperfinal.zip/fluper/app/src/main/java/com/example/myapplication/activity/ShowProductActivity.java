package com.example.myapplication.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.OrientationHelper;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;

import com.example.myapplication.R;
import com.example.myapplication.adapter.ShowProductAdapter;
import com.example.myapplication.dataBase.DatabaseHelper;
import com.example.myapplication.models.Colors;
import com.example.myapplication.models.Product;

import java.util.ArrayList;
import java.util.List;

public class ShowProductActivity extends AppCompatActivity {

    ShowProductAdapter showProductAdapter;
    RecyclerView recyclerviewProductDetails;
    Cursor cursor =null;
    DatabaseHelper mydb ;
    List<Product> productList=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_product);
        recyclerviewProductDetails=findViewById(R.id.recyclerviewProductDetails);
        mydb=new DatabaseHelper(this);
        showProductAdapter = new ShowProductAdapter(ShowProductActivity.this, productList);
        recyclerviewProductDetails.setAdapter(showProductAdapter);
        @SuppressLint("WrongConstant")
        LinearLayoutManager ll = new LinearLayoutManager(ShowProductActivity.this, OrientationHelper.VERTICAL, false);
        recyclerviewProductDetails.setLayoutManager(ll);
        recyclerviewProductDetails.setItemAnimator(new DefaultItemAnimator());


//        List<Colors>colors=productList.get(0).getColorsArrayList();

//        productList.add(new Product(1,"Tootpaste","clean  teethwith pepsodent","20Rs","15Rs","sd","red",colors,"cupcake"));
//        productList.add(new Product(2,"Food","clean  teethwith pepsodent","20Rs","15Rs","sd","red",colors,"cupcake"));
//        productList.add(new Product(3,"Handcraft","clean  teethwith pepsodent","20Rs","15Rs","sd","red",colors,"cupcake"));

        productList.clear();
        cursor = mydb.getAllData();
        if(cursor==null)
        {
            Toast.makeText(this, "12"+cursor, Toast.LENGTH_SHORT).show();
        }
        else {


        if (cursor.getCount() > 0) {
            while (cursor.moveToNext())
            {
                String pro_id=cursor.getString(0);
                String proneme=cursor.getString(1);
                String productDiscription=cursor.getString(2);
                String productRegularPrice=cursor.getString(3);
                String productSaleprice=cursor.getString(4);
                String  productPhoto=cursor.getString(5);
                String productColor=cursor.getString(6);
                String productStores=cursor.getString(7);
                productList.add(new Product(Integer.valueOf(pro_id),proneme,productDiscription,productRegularPrice,productSaleprice,productPhoto
                ,productColor,productStores));
            }
        }
        if(cursor!=null && !cursor.isClosed())

        {
            cursor.close();
        }
        showProductAdapter.notifyDataSetChanged();

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        productList.clear();
        cursor = mydb.getAllData();
        if (cursor == null) {
            Toast.makeText(this, "12" + cursor, Toast.LENGTH_SHORT).show();
        } else {


            if (cursor.getCount() > 0) {
                while (cursor.moveToNext()) {
                    String pro_id = cursor.getString(0);
                    String proneme = cursor.getString(1);
                    String productDiscription = cursor.getString(2);
                    String productRegularPrice = cursor.getString(3);
                    String productSaleprice = cursor.getString(4);
                    String productPhoto = cursor.getString(5);
                    String productColor = cursor.getString(6);
                    String productStores = cursor.getString(7);
                    productList.add(new Product(Integer.valueOf(pro_id), proneme, productDiscription, productRegularPrice, productSaleprice, productPhoto
                            , productColor, productStores));
                }
            }
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
            showProductAdapter.notifyDataSetChanged();

        }
    }


}
