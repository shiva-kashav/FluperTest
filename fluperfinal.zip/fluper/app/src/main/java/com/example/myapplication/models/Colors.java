package com.example.myapplication.models;

public class Colors {

private String colors;

    public String getColors() {
        return colors;
    }

    public void setColors(String colors) {
        this.colors = colors;
    }
}
