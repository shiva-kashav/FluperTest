package com.example.myapplication.models;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.List;

public class Product {
    private Integer id;

    public Product() {
    }

    private String name;

    private String description;

    private String regularPrice;

    private String salePrice;




    public String productPhoto;

    public String colors;

    public List<Colors> colorsArrayList = new ArrayList<>();

    public String stores;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRegularPrice() {
        return regularPrice;
    }

    public void setRegularPrice(String regularPrice) {
        this.regularPrice = regularPrice;
    }

    public String getSalePrice() {
        return salePrice;
    }

    public void setSalePrice(String salePrice) {
        this.salePrice = salePrice;
    }



    public String getColors() {
        return colors;
    }

    public void setColors(String colors) {
        this.colors = colors;
    }

    public List<Colors> getColorsArrayList() {
        return colorsArrayList;
    }

    public void setColorsArrayList(List<Colors> colorsArrayList) {
        this.colorsArrayList = colorsArrayList;
    }

    public Product(Integer id, String name, String description, String regularPrice,
                   String salePrice,String productPhoto,
                   String colors,  String stores) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.regularPrice = regularPrice;
        this.salePrice = salePrice;
        this.colors = colors;
        this.stores = stores;
        this.productPhoto=productPhoto;
    }

    public String getStores() {
        return stores;
    }

    public void setStores(String stores) {
        this.stores = stores;
    }


}
