package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.myapplication.activity.CreateProductActivity;
import com.example.myapplication.activity.ShowProductActivity;
import com.example.myapplication.models.Colors;
import com.example.myapplication.models.Product;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Button btcreateProduct,btshowProduct;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btcreateProduct=findViewById(R.id.btcreateProduct);
        btshowProduct=findViewById(R.id.btshowProduct);

        btcreateProduct.setOnClickListener(this);
        btshowProduct.setOnClickListener(this);

        Product product=new Product();
        Gson gson=new Gson();
        Dictionary<String, String> dictionary = new Hashtable<>();
        // add some elements
        dictionary.put("1", "Chocolate");
        dictionary.put("2", "Cocoa");
        dictionary.put("5", "Coffee");

        product.setStores(dictionary.toString());
        String json=gson.toJson(product);
//        Toast.makeText(this, ""+json, Toast.LENGTH_SHORT).show();
        System.out.println(json);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){

            case R.id.btcreateProduct:
                startActivity(new Intent(MainActivity.this, CreateProductActivity.class));
                break;

            case R.id.btshowProduct:

                startActivity(new Intent(MainActivity.this, ShowProductActivity.class));
                break;
        }
    }
}
